# Trabalho 3 da cadeira de Inteligência Artificial

## Integrantes
* Artur Rossi | 303217
* André Carini | 260843
* Moatan Pedroso Godoy | 246789

## Valor do GA de melhor resultado:
run_ga(5000, 100, 2, 0.05, True) obteve resultado 0

## Valores iniciais de theta_0, theta_1, alpha e num_iterations
theta_0 = 0

theta_1 = 1

alpha = 0.01

num_iterations = 100

Erro médio quadrático = 14.891711085859795
